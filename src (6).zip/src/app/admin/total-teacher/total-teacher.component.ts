import { Component } from '@angular/core';

@Component({
  selector: 'app-total-teacher',
  imports: [],
  templateUrl: './total-teacher.component.html',
  styleUrl: './total-teacher.component.css'
})
export class TotalTeacherComponent {

}
