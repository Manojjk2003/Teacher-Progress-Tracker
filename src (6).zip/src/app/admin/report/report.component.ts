import { Component, signal } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { MatButtonModule } from '@angular/material/button'; 
import { ReportService } from './report.service';
import { CommonModule, JsonPipe, NgFor, NgForOf, NgIf } from '@angular/common';
import { SharedService } from '../shared.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';

import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';


@Component({
  selector: 'app-report',
  imports: [MatSelectModule ,CommonModule,MatInputModule,MatDatepickerModule, MatNativeDateModule, ReactiveFormsModule, FormsModule, MatFormFieldModule,MatCardModule, MatButtonModule, MatListModule ],
  templateUrl: './report.component.html',
  styleUrl: './report.component.css'
})
export class ReportComponent {
  organizations: any[] = [];
  schools: any[] = [];
  teachers: any[] = [];
  selectedOrganizationId: any = '';
  selectedSchoolId: any = '';
  selectedTeacherId: any = '';
  startDate: string = '';
  endDate: string = '';
  teacherReport: any;
  today!: string;


  constructor(
    private reportService: ReportService,
    private sharedService: SharedService
  ) {}

  ngOnInit(): void {
    this.fetchOrganizations();
    const now = new Date();
    this.today = now.toISOString().split('T')[0];
  }
  fetchOrganizations() {
    this.reportService.getOrganizations().subscribe(response => {
      console.log(response);  // Check the structure of the response
      // Access the 'organizations' array from the response object
      if (Array.isArray(response.organizations)) {
        this.organizations = response.organizations;
      } else {
        console.error('Expected an array inside organizations but got:', response.organizations);
      }
    });
  }
  
  
  loadOrganizations(): void {
    this.reportService.getOrganizations().subscribe({
      next: (data) => this.organizations = data,
      error: (error) => console.error('Error fetching organizations:', error)
    });
  }
  onOrganizationChange(): void {
    if (this.selectedOrganizationId) {
      this.reportService.getSchoolsByOrganization(this.selectedOrganizationId).subscribe({
        next: (data) => {
          console.log('Fetched schools:', data);
          // Access the schools array from the response and assign it to this.schools
          if (data.schools && Array.isArray(data.schools)) {
            this.schools = data.schools;
          } else {
            console.error('Expected an array of schools but got:', data.schools);
          }
        },
        error: (error) => console.error('Error fetching schools:', error)
      });
    }
    this.teachers = []; // Reset teachers if organization changes
    this.selectedSchoolId = '';
    this.selectedTeacherId = '';
  }
  
  onSchoolChange(): void {
    if (this.selectedSchoolId) {
      this.reportService.getTeachersBySchool(this.selectedSchoolId).subscribe({
        next: (data) => {
          console.log('Fetched teachers:', data);
          if (data.teachers && Array.isArray(data.teachers)) {
            this.teachers = data.teachers;  // Correctly assign the teachers array
          } else {
            console.error('Expected an array of teachers but got:', data.teachers);
          }
        },
        error: (error) => console.error('Error fetching teachers:', error)
      });
    }
    this.selectedTeacherId = '';
  }
  
  fetchReport(): void {
    if (!this.selectedTeacherId) {
      console.warn('Please select a teacher');
      return;
    }
    const formattedStartDate = this.startDate ? new Date(this.startDate).toISOString().split('T')[0] : '';
    const formattedEndDate = this.endDate ? new Date(this.endDate).toISOString().split('T')[0] : '';

    this.reportService.getTeacherReport(this.selectedTeacherId,  formattedStartDate, formattedEndDate)
      .subscribe({
        next: (data) => {
          this.teacherReport = data;
          console.log('Report fetched:', data);
        },
        error: (error) => console.error('Error fetching report:', error)
      });
  }

  
  downloadReport() {
    const reportElement = document.getElementById('report-content');
  
    if (reportElement) {
      html2canvas(reportElement, { scale: 2 }).then((canvas) => {
        const imgData = canvas.toDataURL('image/png');
  
        const pdf = new jsPDF('p', 'mm', 'a4');
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
  
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
        pdf.save('Teacher-Performance-Report.pdf');
      });
}
}
}
