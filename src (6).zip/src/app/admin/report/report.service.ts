import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  private apiUrl = 'http://localhost:8000'; // change if hosted elsewhere

  constructor(private http: HttpClient,) {}

  getOrganizations(): Observable<any> {
      return this.http.get<any>(`${this.apiUrl}/organizations`).pipe(
        catchError(this.handleError)
      );
    }

    getSchoolsByOrganization(organizationId: string): Observable<any> {
      return this.http.get<any>(`${this.apiUrl}/schools/${organizationId}`).pipe(
        catchError(this.handleError)
      );
    }
    
    getTeachersBySchool(schoolId: string): Observable<any> {
      return this.http.get<any>(`${this.apiUrl}/teachers/${schoolId}`).pipe(
        catchError(this.handleError)
      );
    }
    

  getTeacherReport(teacherId: string, startDate?: string, endDate?: string) {
    let params = new HttpParams();
    if (startDate) params = params.set('start_date', startDate);
    if (endDate) params = params.set('end_date', endDate);

    return this.http.get<any>(`${this.apiUrl}/teacher_report/${teacherId}`, { params });
  }

   private handleError(error: HttpErrorResponse) {
      // Log the error details
      console.error('Error occurred:', error);
     
      let errorMessage = 'Something went wrong; please try again later.';
  
      // Provide more specific error messages depending on error type
      if (error.error instanceof ErrorEvent) {
        // Client-side or network error
        errorMessage = `Client-side error: ${error.error.message}`;
      } else {
        // Backend error
        errorMessage = `Backend error: ${error.status} - ${error.message}`;
      }
     
      // Return an observable with an error message
      return throwError(errorMessage);
    }
}
